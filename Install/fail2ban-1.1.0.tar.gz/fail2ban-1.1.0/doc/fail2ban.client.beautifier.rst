fail2ban.client.beautifier module
=================================

.. automodule:: fail2ban.client.beautifier
    :members:
    :undoc-members:
    :show-inheritance:
