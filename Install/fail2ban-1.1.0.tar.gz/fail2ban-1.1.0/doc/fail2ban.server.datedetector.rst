fail2ban.server.datedetector module
===================================

.. automodule:: fail2ban.server.datedetector
    :members:
    :undoc-members:
    :show-inheritance:
